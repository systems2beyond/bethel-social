import { SocialFeed } from "@/components/Feed/SocialFeed";

export default function Home() {
  return (
    <div className="py-8 px-4">
      <SocialFeed />
    </div>
  );
}
