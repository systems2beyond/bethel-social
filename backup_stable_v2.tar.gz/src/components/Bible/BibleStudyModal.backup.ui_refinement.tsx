'use client';

import React, { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X, Sparkles, BookOpen, Search as SearchIcon, Maximize2, Minimize2, Loader2, ChevronDown, Edit3, RotateCw, History, TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { doc, onSnapshot, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/context/AuthContext';
import { useBible } from '@/context/BibleContext';
import TiptapEditor, { EditorToolbar } from '../Editor/TiptapEditor';
import { cn } from '@/lib/utils';
import { useMediaQuery } from '@/lib/hooks/useMediaQuery';
import BibleReader from './BibleReader';
import BibleAiChatModal from './BibleAiChatModal';
import { bibleSearch } from '@/lib/search/bible-index'; // Import Service

interface BibleStudyModalProps {
    onClose: () => void;
}

export default function BibleStudyModal({ onClose }: BibleStudyModalProps) {
    const { user } = useAuth();
    const {
        isStudyOpen, closeStudy,
        onInsertNote, registerInsertHandler,
        openBible,
        tabs,
        activeTabId,
        searchVersion,
        setSearchVersion
    } = useBible();
    const [editor, setEditor] = useState<any>(null);
    const [notes, setNotes] = useState('');
    const [noteTitle, setNoteTitle] = useState('General Bible Study');
    const [savingNotes, setSavingNotes] = useState(false);

    // Prevent background scroll when open
    useEffect(() => {
        if (isStudyOpen) {
            document.body.classList.add('prevent-scroll');
            document.body.classList.add('modal-open'); // Marker for nested modals
        } else {
            document.body.classList.remove('prevent-scroll');
            document.body.classList.remove('modal-open');
        }
        return () => {
            document.body.classList.remove('prevent-scroll');
            document.body.classList.remove('modal-open');
        };
    }, [isStudyOpen]);

    // Search State
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<any[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [isIndexing, setIsIndexing] = useState(false); // New state for loading index
    const [showResults, setShowResults] = useState(false);

    // Autocomplete & History
    const [searchHistory, setSearchHistory] = useState<string[]>([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const searchInputRef = useRef<HTMLInputElement>(null);

    // Load history on mount
    useEffect(() => {
        setSearchHistory(bibleSearch.getSearchHistory());
    }, []);

    // Debounced Search
    useEffect(() => {
        const timer = setTimeout(() => {
            if (searchQuery.trim()) {
                performSearch(searchQuery);
            }
        }, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    const performSearch = async (query: string) => {
        if (!query.trim()) return;
        setIsSearching(true);
        // setIsIndexing(true); // Only needed for initial load really
        try {
            const results = await bibleSearch.search(query, searchVersion);
            setSearchResults(results.map(hit => ({
                reference: `${hit.book} ${hit.chapter}:${hit.verse}`,
                text: hit.text,
                book: hit.book,
                chapter: hit.chapter, // Store raw for grouping
                verse: hit.verse,
                version: searchVersion.toUpperCase()
            })));
            setShowResults(true); // Auto-show results when they come in
        } catch (error) {
            console.error('Search error:', error);
        } finally {
            setIsSearching(false);
            setIsIndexing(false);
        }
    };

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (searchQuery.trim()) {
            bibleSearch.saveSearchToHistory(searchQuery);
            setSearchHistory(bibleSearch.getSearchHistory());
            performSearch(searchQuery);
            setShowSuggestions(false);
            searchInputRef.current?.blur();
        }
    };

    const handleHistoryClick = (term: string) => {
        setSearchQuery(term);
        bibleSearch.saveSearchToHistory(term);
        setSearchHistory(bibleSearch.getSearchHistory());
        performSearch(term);
        setShowSuggestions(false);
    };

    const toggleSuggestions = (show: boolean) => {
        // slight delay to allow click events to propagate
        setTimeout(() => setShowSuggestions(show), 200);
    };

    const { userData } = useAuth(); // Need to see available custom sources


    // Load Notes on Mount
    useEffect(() => {
        if (!user) return;
        const notesRef = doc(db, 'users', user.uid, 'notes', 'bible-study-general');
        const unsubscribe = onSnapshot(notesRef, (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.content && data.content !== notes) {
                    // Only update if significantly different to avoid cursor jumps?
                    // Tiptap handles content updates well if we don't force it on every keystroke.
                    // But for initial load, it's fine.
                    // actually, we should only setNotes if we don't have local changes?
                    // For now, let's just set on initial load.
                    if (!editor) setNotes(data.content);
                }
                if (data.title) setNoteTitle(data.title);
            } else {
                // If new, set default title based on current context
                const activeTab = tabs.find(t => t.id === activeTabId);
                if (activeTab) {
                    setNoteTitle(`Study: ${activeTab.reference.book} ${activeTab.reference.chapter}`);
                }
            }
        });
        return () => unsubscribe();
    }, [user, editor]); // Depend on editor so we don't overwrite user typing if we add conflict logic later

    const handleSaveNotes = async (content: string, titleOverride?: string) => {
        if (!user) return;
        setSavingNotes(true);
        try {
            const notesRef = doc(db, 'users', user.uid, 'notes', 'bible-study-general');
            await setDoc(notesRef, {
                title: titleOverride || noteTitle,
                content,
                updatedAt: serverTimestamp()
            }, { merge: true });
        } catch (error) {
            console.error('Error saving notes:', error);
        } finally {
            setTimeout(() => setSavingNotes(false), 1000);
        }
    };

    const handleTitleChange = (newTitle: string) => {
        setNoteTitle(newTitle);
        // Save immediately (debounced ideally, but direct for now)
        if (editor) {
            handleSaveNotes(editor.getHTML(), newTitle);
        }
    };

    // Old handleSearch removed in favor of proper separate functions
    // kept performSearch above

    // Get custom sources for dropdown
    const customSources: any[] = userData?.customBibleSources || [];

    const clearSearch = () => {
        setSearchQuery('');
        setSearchResults([]);
        setShowResults(false);
    };

    // Refs
    const modalContainerRef = useRef<HTMLDivElement>(null);
    const videoPlaceholderRef = useRef<HTMLDivElement>(null);

    // Register Bible Insert Handler
    useEffect(() => {
        registerInsertHandler((html) => {
            if (editor) {
                // Focus end to ensure valid selection target
                editor.commands.focus('end');
                editor.commands.insertContent(html);
                const newContent = editor.getHTML();
                handleSaveNotes(newContent);
            }
        });
        return () => registerInsertHandler(null);
    }, [editor, registerInsertHandler]);

    // Ratio-based Resizing Logic (0.0 to 1.0)
    // 1.0 = Full Reader (Notes Hidden)
    // 0.0 = Full Notes (Reader Hidden)
    // 0.5 = 50/50 Split
    const [splitRatio, setSplitRatio] = useState(0.5);
    const [isDragging, setIsDragging] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);
    const [lastSplitRatio, setLastSplitRatio] = useState(0.5);

    // Maximize/Minimize toggles
    // If ratio > 0.9, we consider it "Reader Maximized"
    const isReaderMaximized = splitRatio > 0.95;
    // If ratio < 0.1, we consider it "Notes Maximized"
    const isNotesMaximized = splitRatio < 0.05;

    const toggleReaderMaximize = () => {
        if (isReaderMaximized) {
            // Restore to last non-maximized state (or default 0.5)
            setSplitRatio(lastSplitRatio > 0.9 ? 0.5 : lastSplitRatio);
        } else {
            setLastSplitRatio(splitRatio);
            setSplitRatio(1.0);
        }
    };

    const toggleNotesMaximize = () => {
        if (isNotesMaximized) {
            setSplitRatio(lastSplitRatio < 0.1 ? 0.5 : lastSplitRatio);
        } else {
            setLastSplitRatio(splitRatio);
            setSplitRatio(0.0);
        }
    };

    const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
        setIsDragging(true);
        document.body.style.userSelect = 'none';
    };

    useEffect(() => {
        const handleDrag = (e: MouseEvent | TouchEvent) => {
            if (!isDragging || !containerRef.current) return;

            const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
            const rect = containerRef.current.getBoundingClientRect();
            const relativeY = clientY - rect.top;
            const containerHeight = rect.height;

            // Calculate ratio (clamped 0 to 1)
            // relativeY is the bottom of the reader portion
            let newRatio = relativeY / containerHeight;
            newRatio = Math.max(0, Math.min(newRatio, 1));

            // Snap logic
            if (newRatio > 0.95) newRatio = 1.0;
            if (newRatio < 0.05) newRatio = 0.0;

            setSplitRatio(newRatio);
        };

        const handleDragEnd = () => {
            setIsDragging(false);
            document.body.style.userSelect = '';
            window.removeEventListener('mousemove', handleDrag);
            window.removeEventListener('mouseup', handleDragEnd);
            window.removeEventListener('touchmove', handleDrag);
            window.removeEventListener('touchend', handleDragEnd);
        };

        if (isDragging) {
            window.addEventListener('mousemove', handleDrag);
            window.addEventListener('mouseup', handleDragEnd);
            window.addEventListener('touchmove', handleDrag);
            window.addEventListener('touchend', handleDragEnd);
        };

        return () => {
            window.removeEventListener('mousemove', handleDrag);
            window.removeEventListener('mouseup', handleDragEnd);
            window.removeEventListener('touchmove', handleDrag);
            window.removeEventListener('touchend', handleDragEnd);
        };
    }, [isDragging]);

    const [isAiOpen, setIsAiOpen] = useState(false);
    const [aiMessages, setAiMessages] = useState<any[]>([]);
    const [initialAiQuery, setInitialAiQuery] = useState('');

    const handleOpenAiNotes = (query?: string) => {
        if (query) setInitialAiQuery(query);
        setIsAiOpen(true);
    };

    const handleAddToNotes = (text: string) => {
        if (editor) {
            // Focus end to ensure valid selection target for block insertion
            editor.commands.focus('end');
            editor.commands.insertContent(text);
            const newContent = editor.getHTML();
            handleSaveNotes(newContent);
        }
    };

    const handleLinkClick = (href: string) => {
        console.log("BibleStudyModal: handleLinkClick fired", href);
        if (href.startsWith('verse://')) {
            const ref = decodeURIComponent(href.replace('verse://', ''));
            console.log("BibleStudyModal: Parsed Ref", ref);
            // Regex matches: "Book Chapter[:Verse[-EndVerse]]"
            const match = ref.match(/(.+?)\s(\d+)(?::(\d+)(?:-(\d+))?)?$/);
            console.log("BibleStudyModal: Match", match);

            if (match) {
                const book = match[1].trim();
                const chapter = parseInt(match[2]);
                // match[3] is startVerse (optional), match[4] is endVerse (optional)
                const startVerse = match[3] ? parseInt(match[3]) : undefined;
                const endVerse = match[4] ? parseInt(match[4]) : undefined;

                console.log("BibleStudyModal: Opening Bible", { book, chapter, startVerse, endVerse });
                openBible({ book, chapter, verse: startVerse, endVerse }, true);
            } else {
                // Fallback if regex fails (should catch most things now)
                console.warn("Could not parse verse ref:", ref);
            }
        } else {
            console.log("Opening external link", href);
            window.open(href, '_blank');
        }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-3" ref={modalContainerRef}>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onClose}
                onTouchMove={(e) => e.preventDefault()}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm touch-none"
            />

            <motion.div
                ref={containerRef}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative w-full max-w-[95vw] sm:max-w-7xl h-[90vh] bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
            >
                {/* Fixed Header with Search */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-zinc-800 bg-white dark:bg-zinc-900 z-20 shrink-0 relative gap-4">

                    {/* Title + Icon (Compact) */}
                    <div className="flex items-center gap-3 shrink-0 hidden sm:flex">
                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                            <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <h2 className="font-semibold text-gray-900 dark:text-white">Bible Study</h2>
                    </div>

                    {/* Centered Search Bar with "Google-Like" Dropdown */}
                    <div className="flex-1 max-w-xl mx-auto relative z-50">
                        <form onSubmit={handleSearchSubmit} className="relative shadow-sm rounded-lg">
                            <div className="flex items-center gap-2 relative bg-gray-100 dark:bg-zinc-800 rounded-lg pr-2 border-transparent focus-within:bg-white dark:focus-within:bg-zinc-900 focus-within:shadow-md focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
                                {/* Version Selector */}
                                <div className="relative border-r border-gray-300 dark:border-zinc-700">
                                    <select
                                        value={searchVersion}
                                        onChange={(e) => setSearchVersion(e.target.value)}
                                        className="text-xs font-bold bg-transparent border-none focus:ring-0 text-gray-700 dark:text-gray-300 cursor-pointer py-2.5 pl-3 pr-7 appearance-none outline-none"
                                    >
                                        <option value="kjv" className="text-black dark:text-white">KJV</option>
                                        <option value="web" className="text-black dark:text-white">WEB</option>
                                        {customSources.map((s: any) => (
                                            <option key={s.name} value={s.name} className="text-black dark:text-white">
                                                {s.name}
                                            </option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400 pointer-events-none" />
                                </div>

                                {/* Input */}
                                <div className="relative flex-1">
                                    <SearchIcon className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                    <input
                                        ref={searchInputRef}
                                        type="text"
                                        value={searchQuery}
                                        onChange={(e) => {
                                            setSearchQuery(e.target.value);
                                            setShowSuggestions(true);
                                        }}
                                        onFocus={() => setShowSuggestions(true)}
                                        onBlur={() => toggleSuggestions(false)} // Delay hide
                                        placeholder="Search verses..."
                                        className="w-full pl-9 pr-10 py-2.5 bg-transparent border-none outline-none text-base sm:text-sm text-gray-900 dark:text-white placeholder-gray-500"
                                        autoComplete="off"
                                    />
                                    {searchQuery && (
                                        <button
                                            type="button"
                                            onClick={clearSearch}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-200 dark:hover:bg-zinc-700 rounded-full transition-colors"
                                        >
                                            <X className="w-3 h-3 text-gray-500" />
                                        </button>
                                    )}
                                </div>
                            </div>
                        </form>

                        {/* Dropdown Predictions / History */}
                        <AnimatePresence>
                            {showSuggestions && (
                                <motion.div
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 5 }}
                                    transition={{ duration: 0.15 }}
                                    className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-gray-100 dark:border-zinc-800 overflow-hidden z-[60]"
                                >
                                    {/* STATE 1: Empty Query -> History & Quick Filters */}
                                    {!searchQuery.trim() && (
                                        <div className="p-2">
                                            {searchHistory.length > 0 && (
                                                <div className="mb-3">
                                                    <div className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                                                        <History className="w-3 h-3" />
                                                        Recent Searches
                                                    </div>
                                                    {searchHistory.map((term, i) => (
                                                        <button
                                                            key={i}
                                                            onClick={(e) => {
                                                                e.preventDefault(); // Prevent blur from closing immediately
                                                                handleHistoryClick(term);
                                                            }}
                                                            className="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-800/50 rounded-lg group transition-colors text-left"
                                                        >
                                                            <div className="flex items-center gap-3">
                                                                <Clock className="w-4 h-4 text-gray-400 group-hover:text-blue-500 transition-colors" />
                                                                <span>{term}</span>
                                                            </div>
                                                            <ArrowRight className="w-3 h-3 text-gray-300 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                                                        </button>
                                                    ))}
                                                </div>
                                            )}

                                            {/* Quick Filters */}
                                            <div>
                                                <div className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                                                    <TrendingUp className="w-3 h-3" />
                                                    Quick Access
                                                </div>
                                                <div className="flex flex-wrap gap-2 px-3 pb-2">
                                                    {['Gospels', 'Paul\'s Letters', 'Psalms', 'Proverbs', 'Genesis'].map(tag => (
                                                        <button
                                                            key={tag}
                                                            onMouseDown={(e) => {
                                                                e.preventDefault();
                                                                handleHistoryClick(tag);
                                                            }}
                                                            className="px-3 py-1.5 bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 text-xs font-medium rounded-full hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/30 dark:hover:text-blue-400 transition-colors"
                                                        >
                                                            {tag}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* STATE 2: Typing -> Live Results Preview */}
                                    {searchQuery.trim() && (
                                        <div className="py-2">
                                            {isSearching ? (
                                                <div className="flex items-center justify-center py-4 text-gray-400 gap-2">
                                                    <Loader2 className="w-4 h-4 animate-spin" />
                                                    <span className="text-sm">Searching...</span>
                                                </div>
                                            ) : searchResults.length > 0 ? (
                                                <>
                                                    <div className="px-4 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider flex justify-between items-center bg-gray-50/50 dark:bg-zinc-800/50 border-b border-gray-100 dark:border-zinc-800/50">
                                                        <span>Top Matches</span>
                                                        <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] px-1.5 py-0.5 rounded-full">{searchResults.length}</span>
                                                    </div>
                                                    <div className="max-h-[300px] overflow-y-auto custom-scrollbar p-2">
                                                        {searchResults.slice(0, 5).map((hit, i) => (
                                                            <button
                                                                key={i}
                                                                onClick={() => {
                                                                    openBible({ book: hit.book, chapter: hit.chapter, verse: hit.verse }, true);
                                                                    setShowSuggestions(false);
                                                                    bibleSearch.saveSearchToHistory(searchQuery);
                                                                }}
                                                                className="w-full text-left p-3 hover:bg-blue-50 dark:hover:bg-blue-900/10 rounded-xl transition-colors group mb-1"
                                                            >
                                                                <div className="flex items-center gap-2 mb-1">
                                                                    <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30 px-2 py-0.5 rounded-md">
                                                                        {hit.reference}
                                                                    </span>
                                                                </div>
                                                                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 leading-relaxed">
                                                                    {hit.text}
                                                                </p>
                                                            </button>
                                                        ))}
                                                        <button
                                                            onClick={handleSearchSubmit}
                                                            className="w-full text-center py-3 text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 hover:underline border-t border-gray-100 dark:border-zinc-800 mt-2"
                                                        >
                                                            View all {searchResults.length} results
                                                        </button>
                                                    </div>
                                                </>
                                            ) : (
                                                <div className="text-center py-8 text-gray-400">
                                                    <p className="text-sm">No matches found for "{searchQuery}"</p>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0">
                        <button
                            onClick={() => handleOpenAiNotes()}
                            className="flex items-center gap-2 px-3 py-1.5 bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 rounded-full hover:bg-purple-200 dark:hover:bg-purple-900/60 transition-colors font-medium text-xs sm:text-sm"
                        >
                            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            <span className="hidden sm:inline">Ask AI</span>
                            <span className="inline sm:hidden">AI</span>
                        </button>

                        <div className="w-px h-6 bg-gray-200 dark:bg-zinc-800 mx-1" />

                        <button
                            onClick={toggleReaderMaximize}
                            className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors text-gray-500"
                            title={isReaderMaximized ? "Restore Split View" : "Full Screen Reader"}
                        >
                            {isReaderMaximized ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                        </button>
                        <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors">
                            <X className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>
                </div>

                {/* Scrollable Content Container (Flex Column) */}
                <div className="flex-1 overflow-hidden relative flex flex-col overscroll-contain">

                    {/* TOP PANE: Bible Reader */}
                    <div
                        style={{ height: `${splitRatio * 100}%`, minHeight: 0 }}
                        className={cn(
                            "w-full border-b border-gray-200 dark:border-zinc-800 overflow-hidden relative",
                            !isDragging && "transition-[height] duration-75 ease-out", // Only animate when NOT dragging
                            splitRatio === 0 && "invisible border-none" // Completely hide if ratio is 0
                        )}
                    >
                        <BibleReader />

                        {/* Visual Cue for Search Results when Reader is dominant */}
                        <AnimatePresence>
                            {showResults && searchResults.length > 0 && splitRatio > 0.8 && (
                                <motion.div
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 10 }}
                                    className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg z-20 flex items-center gap-2 pointer-events-none"
                                >
                                    <span>{searchResults.length} results found below</span>
                                    <div className="animate-bounce mt-1">
                                        <ChevronDown className="w-3 h-3" />
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    {/* DRAG HANDLE */}
                    <div
                        onMouseDown={handleDragStart}
                        onTouchStart={handleDragStart}
                        className={cn(
                            "z-50 bg-gray-50 dark:bg-zinc-950 border-y border-gray-200 dark:border-zinc-800 py-1.5 flex items-center justify-center cursor-row-resize hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-colors group relative shrink-0",
                            (splitRatio === 0 || splitRatio === 1) && "py-2" // Slightly larger hit area when snapped
                        )}
                    >
                        {/* Visual Drag Handle Indicator */}
                        <div className={cn(
                            "w-12 h-1 bg-gray-300 dark:bg-zinc-700 rounded-full transition-all duration-300",
                            (showResults && splitRatio > 0.8) ? "bg-blue-400 dark:bg-blue-500 w-16 h-1.5 animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]" : "group-hover:bg-blue-400 dark:group-hover:bg-blue-600"
                        )} />

                        {/* Bouncing Chevron Cue if results hidden */}
                        {(showResults && splitRatio > 0.9) && (
                            <div className="absolute -bottom-6 text-blue-500 animate-bounce">
                                <ChevronDown className="w-4 h-4" />
                            </div>
                        )}
                    </div>

                    {/* BOTTOM PANE: Notes / Results */}
                    <div className="flex-1 flex flex-col min-h-0 bg-white dark:bg-zinc-900 overflow-hidden">
                        {showResults ? (
                            <div className="flex-1 overflow-y-auto custom-scrollbar p-6 bg-gray-50/50 dark:bg-zinc-900/50">
                                <div className="flex items-center justify-between mb-4 sticky top-0 bg-gray-50/95 dark:bg-zinc-900/95 backdrop-blur z-10 py-2 border-b border-transparent">
                                    <div className="flex items-center gap-2">
                                        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Search Results</h3>
                                        <span className="bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 text-xs px-2 py-0.5 rounded-full font-medium">
                                            {searchResults.length}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        {/* Toggle Full Screen for Results */}
                                        <button
                                            onClick={toggleNotesMaximize}
                                            className="text-gray-400 hover:text-gray-600 transition-colors"
                                            title={isNotesMaximized ? "Restore View" : "Full Screen Results"}
                                        >
                                            {isNotesMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                                        </button>
                                        <button onClick={() => setShowResults(false)} className="text-xs text-blue-600 hover:underline font-medium">
                                            Close Results
                                        </button>
                                    </div>
                                </div>

                                {isSearching ? (
                                    <div className="flex flex-col items-center justify-center py-12 gap-3 text-gray-500">
                                        <RotateCw className="w-6 h-6 animate-spin" />
                                        <p>{isIndexing ? `Indexing ${searchVersion.toUpperCase()}... (First run only)` : 'Searching...'}</p>
                                    </div>
                                ) : searchResults.length > 0 ? (
                                    <div className="grid grid-cols-1 gap-4">
                                        {(() => {
                                            const activeTab = tabs.find(t => t.id === activeTabId);
                                            const currentBook = activeTab?.reference.book || '';

                                            // Explicitly group results (use verse.book from Orama)
                                            const currentBookResults = searchResults.filter(v => v.book === currentBook);
                                            const otherResults = searchResults.filter(v => v.book !== currentBook);

                                            const renderVerse = (verse: any, idx: number, isRelevant: boolean) => (
                                                <div
                                                    key={idx}
                                                    onClick={() => openBible({ book: verse.book, chapter: verse.chapter, verse: verse.verse }, true)}
                                                    className={cn(
                                                        "relative p-4 rounded-2xl border cursor-pointer transition-all hover:shadow-md group",
                                                        isRelevant
                                                            ? "bg-blue-50/50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800"
                                                            : "bg-white dark:bg-zinc-900 border-gray-100 dark:border-zinc-800 hover:border-blue-200 dark:hover:border-blue-800"
                                                    )}
                                                >
                                                    {isRelevant && (
                                                        <div className="absolute -top-2 -right-2 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800 shadow-sm">
                                                            Current Book
                                                        </div>
                                                    )}
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <span className={cn(
                                                            "px-2.5 py-1 rounded-full text-xs font-bold",
                                                            isRelevant
                                                                ? "bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300"
                                                                : "bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-zinc-700"
                                                        )}>
                                                            {verse.book} {verse.chapter}:{verse.verse}
                                                        </span>
                                                    </div>
                                                    <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed font-serif">
                                                        {verse.text}
                                                    </p>
                                                </div>
                                            );

                                            return (
                                                <>
                                                    {currentBookResults.length > 0 && (
                                                        <div className="mb-6">
                                                            <h4 className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider mb-3 pl-1">
                                                                Matches in {currentBook}
                                                            </h4>
                                                            <div className="grid gap-3">
                                                                {currentBookResults.map((v, i) => renderVerse(v, i, true))}
                                                            </div>
                                                        </div>
                                                    )}

                                                    {otherResults.length > 0 && (
                                                        <div>
                                                            <h4 className="text-xs font-bold text-gray-500 dark:text-gray-500 uppercase tracking-wider mb-3 pl-1">
                                                                Other Matches
                                                            </h4>
                                                            <div className="grid gap-3">
                                                                {otherResults.map((v, i) => renderVerse(v, i + currentBookResults.length, false))}
                                                            </div>
                                                        </div>
                                                    )}
                                                </>
                                            );
                                        })()}
                                    </div>
                                ) : (
                                    <div className="text-center py-20 text-gray-400">
                                        <p>No results found for "{searchQuery}"</p>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="h-full flex flex-col">
                                {/* Toolbar Header */}
                                <div className="sticky top-0 z-10 bg-white dark:bg-zinc-900 border-b border-gray-100 dark:border-zinc-800 px-4 py-2 flex items-center justify-between shrink-0">
                                    <div className="flex flex-col gap-0.5 flex-1 mr-4">
                                        <div className="flex items-center gap-2">
                                            <Edit3 className="w-4 h-4 text-blue-500 shrink-0" />
                                            <input
                                                type="text"
                                                value={noteTitle}
                                                onChange={(e) => handleTitleChange(e.target.value)}
                                                className="bg-transparent border-none p-0 text-base sm:text-sm font-bold text-gray-800 dark:text-white focus:ring-0 w-full placeholder-gray-400"
                                                placeholder="Note Title..."
                                            />
                                        </div>
                                        {savingNotes && <span className="text-[10px] text-green-600 animate-pulse font-medium ml-6">Saving...</span>}
                                    </div>
                                    <div className="flex items-center gap-2">
                                        {/* Toggle Full Screen for Notes */}
                                        <button
                                            onClick={toggleNotesMaximize}
                                            className="p-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400 hover:text-gray-600 transition-colors"
                                            title={isNotesMaximized ? "Restore View" : "Full Screen Notes"}
                                        >
                                            {isNotesMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                                        </button>
                                    </div>
                                </div>
                                <div className="border-b border-gray-100 dark:border-zinc-800 px-2 bg-gray-50/50 dark:bg-zinc-900/50">
                                    <EditorToolbar
                                        editor={editor}
                                        className="border-none shadow-none bg-transparent mb-0 pb-0 justify-center scale-90 origin-left"
                                    />
                                </div>

                                {/* Scrollable Editor Area */}
                                <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar bg-gray-50 dark:bg-zinc-900/50">
                                    <div className="max-w-4xl mx-auto border border-gray-200 dark:border-zinc-800 rounded-xl overflow-hidden min-h-full bg-white dark:bg-zinc-950 shadow-sm relative">
                                        {/* Watermark/Placeholder if empty? No, Tiptap handles placeholder */}
                                        <TiptapEditor
                                            content={notes}
                                            onChange={(content) => handleSaveNotes(content)}
                                            className="p-6 min-h-[500px] prose dark:prose-invert max-w-none focus:outline-none"
                                            showToolbar={false}
                                            onEditorReady={setEditor}
                                            onAskAi={handleOpenAiNotes}
                                            onLinkClick={handleLinkClick}
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </motion.div>

            <BibleAiChatModal
                isOpen={isAiOpen}
                onClose={() => setIsAiOpen(false)}
                contextId={`${tabs.find(t => t.id === activeTabId)?.reference.book} ${tabs.find(t => t.id === activeTabId)?.reference.chapter}`}
                contextTitle={`Bible Study: ${tabs.find(t => t.id === activeTabId)?.reference.book} ${tabs.find(t => t.id === activeTabId)?.reference.chapter}`}
                initialQuery={initialAiQuery}
                messages={aiMessages}
                onMessagesChange={setAiMessages}
                onInsertToNotes={handleAddToNotes}
                preserveScrollLockOnClose={true}
            />
        </div >
    );
}
