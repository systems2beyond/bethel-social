import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useBible } from '@/context/BibleContext';
import { db } from '@/lib/firebase';
import { collection, query, orderBy, limit, onSnapshot, where, getDocs } from 'firebase/firestore';

export function usePlatformContext() {
    const { user } = useAuth();
    const { reference, tabs, activeTabId } = useBible();

    const [contextData, setContextData] = useState({
        events: [] as string[],
        posts: [] as string[],
        notes: [] as string[],
        groups: [] as string[],
        notifications: 0,
        bible: ''
    });

    // 1. Bible Context (Immediate)
    useEffect(() => {
        if (!tabs || tabs.length === 0) {
            setContextData(prev => ({ ...prev, bible: 'No active bible tabs.' }));
            return;
        }

        const activeTab = tabs.find(t => t.id === activeTabId);
        const activeRef = activeTab?.reference || reference;

        const openTabsList = tabs.map(t =>
            `${t.reference.book} ${t.reference.chapter}${t.reference.verse ? `:${t.reference.verse}` : ''}`
        ).join(', ');

        const bibleString = `Current Active Tab: ${activeRef.book} ${activeRef.chapter}${activeRef.verse ? `:${activeRef.verse}` : ''}. Open Tabs: ${openTabsList}`;

        setContextData(prev => ({ ...prev, bible: bibleString }));
    }, [tabs, activeTabId, reference]);

    // 2. Firestore Subscriptions (Events, Posts, Groups, Notifications, Notes)
    useEffect(() => {
        if (!user) return;

        // Events: Next 5 upcoming
        const eventsQ = query(
            collection(db, 'events'),
            where('startDate', '>=', new Date().toISOString()),
            orderBy('startDate', 'asc'),
            limit(5)
        );

        // Posts: Latest 3
        const postsQ = query(
            collection(db, 'posts'),
            orderBy('createdAt', 'desc'),
            limit(3)
        );

        // Notes: Latest 3 modified by user
        const notesQ = query(
            collection(db, 'users', user.uid, 'notes'),
            orderBy('updatedAt', 'desc'),
            limit(3)
        );

        // Notifications: Unread count (Root Collection)
        const notifsQ = query(
            collection(db, 'notifications'),
            where('toUserId', '==', user.uid),
            where('viewed', '==', false), // 'viewed' is the field used in ActivityContext, 'read' might be wrong? ActivityContext uses 'viewed'.
            limit(10)
        );

        // Groups: Member of
        const groupsQ = query(
            collection(db, 'groups'),
            where('members', 'array-contains', user.uid),
            limit(5)
        );

        const unsubEvents = onSnapshot(eventsQ, (snap) => {
            const events = snap.docs.map(d => {
                const data = d.data();
                return `${data.title} (${new Date(data.startDate).toLocaleDateString()})`;
            });
            setContextData(prev => ({ ...prev, events }));
        }, (err) => console.error("Err fetching events context:", err));

        const unsubPosts = onSnapshot(postsQ, (snap) => {
            const posts = snap.docs.map(d => `${d.data().content?.substring(0, 50)}...`);
            setContextData(prev => ({ ...prev, posts }));
        }, (err) => console.error("Err fetching posts context:", err));

        const unsubNotes = onSnapshot(notesQ, (snap) => {
            const notes = snap.docs.map(d => `"${d.data().title}" (edited ${d.data().updatedAt?.toDate ? d.data().updatedAt.toDate().toLocaleDateString() : 'recently'})`);
            setContextData(prev => ({ ...prev, notes }));
        }, (err) => console.error("Err fetching notes context:", err));

        const unsubNotifs = onSnapshot(notifsQ, (snap) => {
            setContextData(prev => ({ ...prev, notifications: snap.size }));
        }, (err) => console.error("Err fetching notifications context:", err));

        const unsubGroups = onSnapshot(groupsQ, (snap) => {
            const groups = snap.docs.map(d => d.data().name);
            setContextData(prev => ({ ...prev, groups }));
        }, (err) => console.error("Err fetching groups context:", err));

        return () => {
            unsubEvents();
            unsubPosts();
            unsubNotes();
            unsubNotifs();
            unsubGroups();
        };
    }, [user]);

    // Construct the final system string
    const contextString = `
[SYSTEM_CONTEXT]
User: ${user?.displayName || 'Guest'}
Current Time: ${new Date().toLocaleString()}

BIBLE STATE:
${contextData.bible}

UPCOMING EVENTS:
${contextData.events.length > 0 ? contextData.events.join('\n') : 'No upcoming events found.'}

RECENT CHURCH POSTS:
${contextData.posts.length > 0 ? contextData.posts.join('\n') : 'No recent posts.'}

USER'S RECENT NOTES:
${contextData.notes.length > 0 ? contextData.notes.join('\n') : 'No recent notes.'}

USER GROUPS:
${contextData.groups.length > 0 ? contextData.groups.join(', ') : 'Not in any groups.'}

UNREAD NOTIFICATIONS: ${contextData.notifications}
[/SYSTEM_CONTEXT]

[INSTRUCTIONS]
You are Matthew, a helpful church assistant for Bethel Metropolitan.
- Tone: Warm, concise, and helpful. Like a knowledgeable church volunteer.
- Context: You have access to the user's open bible tabs, upcoming events, and notes (listed above). Use them to answer matching questions naturally.
- Greetings: Do NOT start every message with "Hello" or "Hi". Only greet if the user greets you first or it's the very first exchange. For follow-up questions, dive straight into the answer.
- Bible: If the user reads a verse, offer insights relevant to that specific text.
[/INSTRUCTIONS]
    `.trim();

    return { contextString, contextData };
}
