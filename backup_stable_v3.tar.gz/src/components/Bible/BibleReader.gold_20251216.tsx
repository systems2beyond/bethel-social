'use client';

import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, ChevronRight, ChevronDown, Loader2, Copy, Edit3, Check, BookOpen, PenLine, X, Plus, Sparkles, Folder } from 'lucide-react';
import { useBible, TabGroup, Tab } from '@/context/BibleContext';
import { cn } from '@/lib/utils';

// Bible Data Structure
interface BibleBook {
    id: string;
    name: string;
    chapters: number;
}

// Simplified list of books for dropdown (could be fetched, but static is faster)
const BIBLE_BOOKS: BibleBook[] = [
    { id: 'GEN', name: 'Genesis', chapters: 50 },
    { id: 'EXO', name: 'Exodus', chapters: 40 },
    { id: 'LEV', name: 'Leviticus', chapters: 27 },
    { id: 'NUM', name: 'Numbers', chapters: 36 },
    { id: 'DEU', name: 'Deuteronomy', chapters: 34 },
    { id: 'JOS', name: 'Joshua', chapters: 24 },
    { id: 'JDG', name: 'Judges', chapters: 21 },
    { id: 'RUT', name: 'Ruth', chapters: 4 },
    { id: '1SA', name: '1 Samuel', chapters: 31 },
    { id: '2SA', name: '2 Samuel', chapters: 24 },
    { id: '1KI', name: '1 Kings', chapters: 22 },
    { id: '2KI', name: '2 Kings', chapters: 25 },
    { id: '1CH', name: '1 Chronicles', chapters: 29 },
    { id: '2CH', name: '2 Chronicles', chapters: 36 },
    { id: 'EZR', name: 'Ezra', chapters: 10 },
    { id: 'NEH', name: 'Nehemiah', chapters: 13 },
    { id: 'EST', name: 'Esther', chapters: 10 },
    { id: 'JOB', name: 'Job', chapters: 42 },
    { id: 'PSA', name: 'Psalms', chapters: 150 },
    { id: 'PRO', name: 'Proverbs', chapters: 31 },
    { id: 'ECC', name: 'Ecclesiastes', chapters: 12 },
    { id: 'SNG', name: 'Song of Solomon', chapters: 8 },
    { id: 'ISA', name: 'Isaiah', chapters: 66 },
    { id: 'JER', name: 'Jeremiah', chapters: 52 },
    { id: 'LAM', name: 'Lamentations', chapters: 5 },
    { id: 'EZK', name: 'Ezekiel', chapters: 48 },
    { id: 'DAN', name: 'Daniel', chapters: 12 },
    { id: 'HOS', name: 'Hosea', chapters: 14 },
    { id: 'JOL', name: 'Joel', chapters: 3 },
    { id: 'AMO', name: 'Amos', chapters: 9 },
    { id: 'OBA', name: 'Obadiah', chapters: 1 },
    { id: 'JON', name: 'Jonah', chapters: 4 },
    { id: 'MIC', name: 'Micah', chapters: 7 },
    { id: 'NAM', name: 'Nahum', chapters: 3 },
    { id: 'HAB', name: 'Habakkuk', chapters: 3 },
    { id: 'ZEP', name: 'Zephaniah', chapters: 3 },
    { id: 'HAG', name: 'Haggai', chapters: 2 },
    { id: 'ZEC', name: 'Zechariah', chapters: 14 },
    { id: 'MAL', name: 'Malachi', chapters: 4 },
    { id: 'MAT', name: 'Matthew', chapters: 28 },
    { id: 'MRK', name: 'Mark', chapters: 16 },
    { id: 'LUK', name: 'Luke', chapters: 24 },
    { id: 'JHN', name: 'John', chapters: 21 },
    { id: 'ACT', name: 'Acts', chapters: 28 },
    { id: 'ROM', name: 'Romans', chapters: 16 },
    { id: '1CO', name: '1 Corinthians', chapters: 16 },
    { id: '2CO', name: '2 Corinthians', chapters: 13 },
    { id: 'GAL', name: 'Galatians', chapters: 6 },
    { id: 'EPH', name: 'Ephesians', chapters: 6 },
    { id: 'PHP', name: 'Philippians', chapters: 4 },
    { id: 'COL', name: 'Colossians', chapters: 4 },
    { id: '1TH', name: '1 Thessalonians', chapters: 5 },
    { id: '2TH', name: '2 Thessalonians', chapters: 3 },
    { id: '1TI', name: '1 Timothy', chapters: 6 },
    { id: '2TI', name: '2 Timothy', chapters: 4 },
    { id: 'TIT', name: 'Titus', chapters: 3 },
    { id: 'PHM', name: 'Philemon', chapters: 1 },
    { id: 'HEB', name: 'Hebrews', chapters: 13 },
    { id: 'JAS', name: 'James', chapters: 5 },
    { id: '1PE', name: '1 Peter', chapters: 5 },
    { id: '2PE', name: '2 Peter', chapters: 3 },
    { id: '1JN', name: '1 John', chapters: 5 },
    { id: '2JN', name: '2 John', chapters: 1 },
    { id: '3JN', name: '3 John', chapters: 1 },
    { id: 'JUD', name: 'Jude', chapters: 1 },
    { id: 'REV', name: 'Revelation', chapters: 22 },
];

// Supported Versions (Free/Public Domain)
const BIBLE_VERSIONS = [
    { id: 'kjv', name: 'King James Version (KJV)' },
    { id: 'web', name: 'World English Bible (WEB)' },
    { id: 'asv', name: 'American Standard Version (ASV)' },
];

interface BibleReaderProps {
    onInsertNote?: (text: string) => void;
    onAskAi?: (query: string) => void;
}

export default function BibleReader({ onInsertNote, onAskAi }: BibleReaderProps) {
    const {
        reference, setReference, version, setVersion,
        openStudy, isStudyOpen, openBible,
        tabs, activeTabId, setActiveTab, addTab, closeTab,
        groups, toggleGroupCollapse, closeGroup
    } = useBible();

    const [text, setText] = useState<{ verse: number, text: string }[]>([]);
    const [loading, setLoading] = useState(false);
    const [selectedVerses, setSelectedVerses] = useState<number[]>([]);
    const scrollRef = useRef<HTMLDivElement>(null);
    const contentRef = useRef<HTMLDivElement>(null);

    // Persist scroll position when switching tabs
    useEffect(() => {
        // Restore scroll when active tab changes
        const currentTab = tabs.find(t => t.id === activeTabId);
        if (currentTab && currentTab.scrollPosition && contentRef.current) {
            contentRef.current.scrollTop = currentTab.scrollPosition;
        }
    }, [activeTabId, tabs]);

    // Fetch Bible Text
    useEffect(() => {
        const fetchChapter = async () => {
            if (!reference.book || !reference.chapter) {
                setLoading(false);
                return;
            }

            setLoading(true);
            try {
                // Map ID to Name for API if needed
                const bookName = BIBLE_BOOKS.find(b => b.name === reference.book || b.id === reference.book)?.name || reference.book;
                const safeBook = encodeURIComponent(bookName);

                // Use direct API call to support static export
                const res = await fetch(`https://bible-api.com/${safeBook}+${reference.chapter}?translation=${version.toLowerCase()}`);

                if (!res.ok) throw new Error('Failed to fetch');

                const data = await res.json();

                if (data && data.verses) {
                    setText(data.verses);
                } else {
                    setText([]);
                }

            } catch (error) {
                console.error("Failed to fetch Bible text:", error);
                setText([]);
            } finally {
                setLoading(false);
            }
        };

        fetchChapter();
        setSelectedVerses([]);
    }, [reference.book, reference.chapter, version, activeTabId]); // Re-fetch on tab switch if needed (ref changes)

    // Scroll to verse when text loads (and auto-select)
    useEffect(() => {
        if (!loading && text.length > 0 && reference.verse) {
            const targetVerse = reference.verse; // Capture current value
            const targetEndVerse = reference.endVerse;

            // Small timeout to allow DOM paint
            const timer = setTimeout(() => {
                const element = document.getElementById(`verse-${targetVerse}`);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });

                    // User requested NO auto-highlight, just scroll.
                    // We only auto-select if explicitly deep-linked with range (maybe?)
                    // User said: "dont highlight the text let the user do that just sscroll to the text"
                    // So we will remove the single verse selection.

                    // Keeping range selection if explicitly defined (optional, but usually "Note" links are single verses)
                    if (targetEndVerse) {
                        const range: number[] = [];
                        for (let i = targetVerse; i <= targetEndVerse; i++) {
                            range.push(i);
                        }
                        // If it's a range, maybe we still select? The user said "text", implies single verse.
                        // I'll comment it out to be safe and strictly follow "let the user do that".
                        // actually, ranges are rare deep links. If I clicked "John 3:16-18", I probably want to see that block.
                        // But for single verse links, definitely no highlight.
                        // I will DISABLE ALL auto-highlight for now to be safe.
                        // setSelectedVerses(range);
                    } else {
                        // setSelectedVerses([targetVerse]);
                    }
                }
            }, 300); // 300ms delay to be safe
            return () => clearTimeout(timer);
        }
    }, [loading, text, reference.verse, reference.book, reference.chapter, reference.endVerse]);

    const handleVerseClick = (verseNum: number) => {
        if (selectedVerses.includes(verseNum)) {
            setSelectedVerses(selectedVerses.filter(v => v !== verseNum));
        } else {
            setSelectedVerses([...selectedVerses, verseNum].sort((a, b) => a - b));
        }
    };

    const handleNextChapter = () => {
        const currentBookIndex = BIBLE_BOOKS.findIndex(b => b.name === reference.book || b.id === reference.book);
        const currentBook = BIBLE_BOOKS[currentBookIndex];

        if (reference.chapter < currentBook.chapters) {
            setReference({ ...reference, chapter: reference.chapter + 1, verse: undefined });
        } else if (currentBookIndex < BIBLE_BOOKS.length - 1) {
            // Next Book
            setReference({ book: BIBLE_BOOKS[currentBookIndex + 1].name, chapter: 1, verse: undefined });
        }
    };

    const handlePrevChapter = () => {
        if (reference.chapter > 1) {
            setReference({ ...reference, chapter: reference.chapter - 1, verse: undefined });
        } else {
            // Previous Book
            const currentBookIndex = BIBLE_BOOKS.findIndex(b => b.name === reference.book || b.id === reference.book);
            if (currentBookIndex > 0) {
                const prevBook = BIBLE_BOOKS[currentBookIndex - 1];
                setReference({ book: prevBook.name, chapter: prevBook.chapters, verse: undefined });
            }
        }
    };

    const handleAddToNotes = () => {
        if (!onInsertNote || selectedVerses.length === 0) return;

        // Format selected verses
        const selectedText = text
            .filter(t => selectedVerses.includes(t.verse))
            .map(t => `<sup style="font-size: 0.7em; color: #9ca3af;">${t.verse}</sup> ${t.text}`)
            .join(' ');

        const referenceText = `${reference.book} ${reference.chapter}:${selectedVerses[0]}${selectedVerses.length > 1 ? `-${selectedVerses[selectedVerses.length - 1]}` : ''}`;

        const html = `<blockquote><p>${selectedText}</p><p><strong>— ${referenceText} (${version.toUpperCase()})</strong></p></blockquote><p></p>`;

        // Open in new tab implicitly by inserting (user might want to keep reading)
        // But for now just insert
        onInsertNote(html);
        setSelectedVerses([]); // Clear selection after adding
    };

    useEffect(() => {
        console.log(`[BibleReader] BibleTabs Rendered. Count: ${tabs.length}, Active: ${activeTabId}`);
    }, [tabs, activeTabId]);

    return (
        <div className="flex flex-col h-full bg-white dark:bg-zinc-900 relative rounded-lg border border-gray-200 dark:border-zinc-800">
            {/* Header / Tabs */}
            <div className="flex items-center justify-between px-4 py-2 border-b border-gray-100 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-800/50 backdrop-blur-sm">
                <div className="flex items-end gap-1 overflow-x-auto no-scrollbar max-w-[calc(100%-120px)] h-full pb-1">
                    {/* Render Ungrouped Tabs First */}
                    {tabs.filter(t => !t.groupId).map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={cn(
                                "relative px-3 py-1.5 min-w-[100px] max-w-[140px] cursor-pointer rounded-t-lg transition-all group border-r border-slate-200 dark:border-zinc-700/50 flex items-center justify-between gap-2",
                                activeTabId === tab.id
                                    ? "bg-white dark:bg-zinc-800 text-blue-600 dark:text-blue-400 z-10 border-t-2 border-t-blue-500 shadow-sm"
                                    : "bg-gray-100 dark:bg-zinc-900/50 text-gray-500 dark:text-gray-500 hover:bg-white dark:hover:bg-zinc-800 hover:text-gray-700 dark:hover:text-gray-300 border-t-2 border-t-transparent"
                            )}
                        >
                            <span className="truncate text-xs font-medium">
                                {tab.reference.book} {tab.reference.chapter}
                            </span>
                            <span
                                onClick={(e) => {
                                    e.stopPropagation();
                                    closeTab(tab.id);
                                }}
                                className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-gray-200 dark:hover:bg-zinc-700 rounded-full transition-all"
                            >
                                <X className="w-3 h-3 text-gray-400" />
                            </span>
                        </button>
                    ))}

                    {/* Render Groups with Dropdown Logic */}
                    {groups.map(group => (
                        <GroupDropdown
                            key={group.id}
                            group={group}
                            tabs={tabs.filter(t => t.groupId === group.id)}
                            activeTabId={activeTabId}
                            setActiveTab={setActiveTab}
                            toggleGroupCollapse={toggleGroupCollapse}
                            closeGroup={closeGroup}
                            closeTab={closeTab}
                        />
                    ))}

                    <button
                        onClick={() => openBible(undefined, true)}
                        className="p-1.5 ml-1 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                        title="New Tab"
                    >
                        <Plus className="w-4 h-4" />
                    </button>
                </div>
            </div>

            {/* Navigation Bar */}
            <div className="flex items-center justify-between px-4 py-2 bg-white dark:bg-zinc-900 border-b border-gray-100 dark:border-zinc-800 shadow-sm z-10">
                <div className="flex items-center gap-2">
                    <button onClick={handlePrevChapter} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full text-gray-500">
                        <ChevronLeft className="w-5 h-5" />
                    </button>
                </div>

                <div className="flex items-center gap-2">
                    {/* Version Selector */}
                    <select
                        value={version}
                        onChange={(e) => setVersion(e.target.value)}
                        className="bg-transparent font-bold text-blue-600 dark:text-blue-400 text-sm focus:outline-none cursor-pointer uppercase tracking-wider"
                    >
                        {BIBLE_VERSIONS.map(v => (
                            <option key={v.id} value={v.id}>{v.id.toUpperCase()}</option>
                        ))}
                    </select>

                    <div className="h-4 w-px bg-gray-300 dark:bg-zinc-700 mx-1" />

                    {/* Book Selector */}
                    <select
                        value={reference.book}
                        onChange={(e) => setReference({ ...reference, book: e.target.value, chapter: 1 })}
                        className="bg-transparent font-semibold text-gray-900 dark:text-white text-sm focus:outline-none cursor-pointer max-w-[100px] sm:max-w-none truncate"
                    >
                        {BIBLE_BOOKS.map(b => (
                            <option key={b.id} value={b.name}>{b.name}</option>
                        ))}
                    </select>

                    {/* Chapter Selector */}
                    <select
                        value={reference.chapter}
                        onChange={(e) => setReference({ ...reference, chapter: parseInt(e.target.value) })}
                        className="bg-transparent font-semibold text-gray-900 dark:text-white text-sm focus:outline-none cursor-pointer"
                    >
                        {(() => {
                            const currentBook = BIBLE_BOOKS.find(b => b.name === reference.book || b.id === reference.book);
                            return Array.from({ length: currentBook?.chapters || 1 }, (_, i) => i + 1).map(c => (
                                <option key={c} value={c}>{c}</option>
                            ));
                        })()}
                    </select>
                </div>

                <div className="flex items-center gap-2">
                    <button onClick={handleNextChapter} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full text-gray-500">
                        <ChevronRight className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {/* Text Display */}
            <div ref={contentRef} className="flex-1 overflow-y-auto p-6 scroll-smooth custom-scrollbar bg-white dark:bg-zinc-900">
                {loading ? (
                    <div className="flex items-center justify-center h-full text-gray-400">
                        <Loader2 className="w-8 h-8 animate-spin" />
                    </div>
                ) : (
                    <div className="max-w-4xl mx-auto space-y-1">
                        <h3 className="text-3xl font-serif font-bold text-center mb-10 text-gray-900 dark:text-white">
                            {reference.book} {reference.chapter}
                        </h3>
                        <div className="leading-[2.2] text-xl font-serif text-gray-800 dark:text-gray-200">
                            {text.map((verse) => {
                                const isSelected = selectedVerses.includes(verse.verse);
                                // Check for paragraph breaks (double newline usually means new paragraph)
                                const parts = verse.text.split(/\n\s*\n/);

                                return (
                                    <React.Fragment key={verse.verse}>
                                        <span
                                            id={`verse-${verse.verse}`}
                                            onClick={() => handleVerseClick(verse.verse)}
                                            className={cn(
                                                "relative cursor-pointer transition-colors duration-200 px-1 rounded hover:bg-gray-100 dark:hover:bg-zinc-800",
                                                isSelected && "bg-amber-200 dark:bg-amber-900/50 text-gray-900 dark:text-white decoration-clone"
                                            )}
                                        >
                                            <sup className="text-[0.6em] font-sans text-gray-400 mr-1 select-none font-bold align-top top-[-0.2em] relative">{verse.verse}</sup>
                                            {verse.text}
                                        </span>
                                        {/* Add spacing if the verse text ends with a newline or has one */}
                                        {verse.text.includes('\n') && <span className="block h-4" />}
                                    </React.Fragment>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Read & Study Button (Only in Quick View) */}
                {!isStudyOpen && !loading && text.length > 0 && (
                    <div className="max-w-xl mx-auto mt-12 mb-8 px-4">
                        <button
                            onClick={openStudy}
                            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium shadow-sm transition-colors flex items-center justify-center gap-2"
                        >
                            <BookOpen className="w-5 h-5" />
                            Open in Read & Study Mode
                        </button>
                        <p className="text-center text-xs text-gray-500 mt-2">
                            Open full screen with study notes and search tools.
                        </p>
                    </div>
                )}
            </div>

            {/* Floating Action Bar (Selection) */}
            {selectedVerses.length > 0 && (
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-2 rounded-full shadow-xl flex items-center gap-4 z-20 animate-in slide-in-from-bottom-4 fade-in duration-200">
                    <span className="text-sm font-medium whitespace-nowrap">
                        {selectedVerses.length} selected
                    </span>
                    <div className="h-4 w-px bg-white/20 dark:bg-black/10" />

                    {onInsertNote && (
                        <button
                            onClick={handleAddToNotes}
                            className="flex items-center gap-2 text-sm font-medium hover:text-amber-400 dark:hover:text-amber-600 transition-colors"
                        >
                            <PenLine className="w-4 h-4" />
                            Add to Notes
                        </button>
                    )}

                    <button
                        onClick={() => {
                            const selectedText = text
                                .filter(t => selectedVerses.includes(t.verse))
                                .map(t => `${t.verse} ${t.text}`)
                                .join(' ');

                            // Call parent handler
                            if (onAskAi) {
                                onAskAi(`"${selectedText}"\n\n`);
                            }
                        }}
                        className="flex items-center gap-2 text-sm font-medium hover:text-purple-400 dark:hover:text-purple-300 transition-colors"
                    >
                        <Sparkles className="w-4 h-4" />
                        Ask AI
                    </button>

                    <div className="h-4 w-px bg-white/20 dark:bg-black/10" />

                    <button
                        onClick={() => {
                            // Simple copy to clipboard
                            const selectedText = text
                                .filter(t => selectedVerses.includes(t.verse))
                                .map(t => `${t.verse} ${t.text}`)
                                .join('\n');
                            navigator.clipboard.writeText(`${reference.book} ${reference.chapter}:${selectedVerses.join(',')}\n${selectedText}`);
                            setSelectedVerses([]);
                        }}
                        className="flex items-center gap-2 text-sm font-medium hover:text-amber-400 dark:hover:text-amber-600 transition-colors"
                    >
                        <Copy className="w-4 h-4" />
                        Copy
                    </button>
                </div>
            )}
        </div>
    );
}

interface GroupDropdownProps {
    group: TabGroup;
    tabs: Tab[];
    activeTabId: string;
    setActiveTab: (id: string) => void;
    toggleGroupCollapse: (id: string) => void;
    closeGroup: (id: string) => void;
    closeTab: (id: string) => void;
}

function GroupDropdown({ group, tabs, activeTabId, setActiveTab, toggleGroupCollapse, closeGroup, closeTab }: GroupDropdownProps) {
    const buttonRef = useRef<HTMLDivElement>(null);
    const [coords, setCoords] = useState({ top: 0, left: 0, width: 200 });
    const isHex = group.color.startsWith('#');

    // Update coordinates when opening
    useLayoutEffect(() => {
        if (!group.isCollapsed && buttonRef.current) {
            const rect = buttonRef.current.getBoundingClientRect();
            // Align dropdown logic
            setCoords({
                top: rect.bottom + 8, // slight gap
                left: Math.max(16, rect.left), // Prevent going off-screen left
                width: Math.max(200, rect.width)
            });
        }
    }, [group.isCollapsed]);

    return (
        <>
            <div
                ref={buttonRef}
                className={cn(
                    "flex items-center h-[36px] mt-auto rounded-t-lg mx-1 transition-all border-b-0 cursor-pointer group select-none",
                    !group.isCollapsed ? "bg-white dark:bg-zinc-800 z-20 relative" : "bg-transparent hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                )}
                style={{
                    border: `1px solid ${group.color}`,
                    borderBottom: !group.isCollapsed ? 'none' : undefined,
                    backgroundColor: group.isCollapsed ? (isHex ? `${group.color}15` : undefined) : undefined
                }}
                onClick={() => toggleGroupCollapse(group.id)}
            >
                <div className="flex items-center gap-1.5 px-3 py-1.5">
                    {group.isCollapsed ? <ChevronRight className="w-3.5 h-3.5 text-gray-400" /> : <ChevronDown className="w-3.5 h-3.5 text-gray-400" />}
                    <Folder className="w-3.5 h-3.5" style={{ color: group.color }} />
                    <span className="text-[11px] font-bold uppercase tracking-wider text-gray-600 dark:text-gray-300 truncate max-w-[100px]">
                        {group.name}
                    </span>
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            closeGroup(group.id);
                        }}
                        className="ml-1 opacity-0 group-hover:opacity-100 hover:text-red-400 transition-opacity"
                    >
                        <X className="w-3 h-3" />
                    </button>
                </div>

                {/* Active Indicator Line if Collapsed but Child Active */}
                {group.isCollapsed && tabs.some(t => t.id === activeTabId) && (
                    <div className="absolute bottom-[-1px] left-0 right-0 h-[3px] z-20" style={{ backgroundColor: group.color }} />
                )}
            </div>

            {/* Portal Dropdown */}
            {!group.isCollapsed && createPortal(
                <div className="fixed inset-0 z-[99999] isolate pointer-events-none">
                    {/* Backdrop for click-outside */}
                    <div className="absolute inset-0 pointer-events-auto" onClick={() => toggleGroupCollapse(group.id)} />

                    {/* Dropdown Content */}
                    <div
                        className="absolute pointer-events-auto bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 shadow-xl rounded-b-lg rounded-r-lg max-h-[300px] overflow-y-auto custom-scrollbar flex flex-col p-1 animate-in fade-in zoom-in-95 duration-100 origin-top-left"
                        style={{
                            top: coords.top,
                            left: coords.left,
                            minWidth: '220px',
                            maxWidth: '300px',
                            borderTop: `2px solid ${group.color}`
                        }}
                        onClick={e => e.stopPropagation()}
                    >
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => {
                                    setActiveTab(tab.id);
                                    // Optional: Close dropdown on selection? User said "drop down so they can see everything". 
                                    // Usually users want to switch tabs. I'll keep it open for "Workbook" feel, or close? 
                                    // Standard tabs don't close container. But this is a "Dropdown".
                                    // Let's Keep it Open for now as it acts like a "Folder". User can click outside to close.
                                }}
                                className={cn(
                                    "flex items-center justify-between w-full px-3 py-2 text-left rounded-md transition-colors text-xs mb-0.5",
                                    activeTabId === tab.id
                                        ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 font-medium"
                                        : "hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300"
                                )}
                            >
                                <span>{tab.reference.book} {tab.reference.chapter}</span>
                                <span
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        closeTab(tab.id);
                                    }}
                                    className="p-1 hover:bg-gray-200 dark:hover:bg-zinc-700 rounded-full text-gray-400 hover:text-red-400 opacity-60 hover:opacity-100"
                                >
                                    <X className="w-3 h-3" />
                                </span>
                            </button>
                        ))}
                        {tabs.length === 0 && (
                            <div className="text-center py-2 text-xs text-gray-400 italic">Empty Group</div>
                        )}
                    </div>
                </div>
                , document.body)}
        </>
    );
}
